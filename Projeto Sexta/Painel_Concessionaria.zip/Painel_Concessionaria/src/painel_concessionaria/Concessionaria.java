/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package painel_concessionaria;

/**
 *
 * @author autologon
 */
public class Concessionaria {
    private String marca;
    private String modelo;
    private int valor;
    private int ano;
    private String tipo;

    public Concessionaria(String marca, String modelo, int valor, int ano, String tipo) {
        this.marca = marca;
        this.modelo = modelo;
        this.valor = valor;
        this.ano = ano;
        this.tipo = tipo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "\nmarca=" + marca + ", modelo=" + modelo + ", valor=" + valor + ", ano=" + ano + ", tipo=" + tipo + "\n";
    }
    
    
}
